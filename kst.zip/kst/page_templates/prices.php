<?
/*
Template name: Цены

*/
get_header(); ?>
<div class="col col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 breadcrumbs">
<? bcn_display(); ?>
</div>
<section id="main-content">
<? do_action('left_sidebar'); ?>
	<div class="col col-12 col-sm-12 col-md-8 col-lg-9 col-xl-9" id="content">
<?
	while ( have_posts() ) : the_post();
		$banner = get_field('баннер_страницы', get_the_ID());
		$banner_title = get_field('запись_на_баннере', get_the_ID());
?>
		<script>
			$('.parallax-window').parallax({imageSrc: '<? echo $banner['url']; ?>'});
			$('#banner_title').html('<? echo $banner_title; ?>');
		</script>
<?
		the_content();
	endwhile;
	//$menu = wp_get_nav_menu_items('Главное меню');
?>	
		<h1 style="text-align: center; margin-bottom: 50px;"><span style="color: #2d70cc;">Цены на услуги по диагностике заболеваний, лечению зубов, отбеливанию, протезированию.</span></h1>
		<div class="col col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
			<table class="price-head" style="width: 100%;">
				<tr>
					<td style="width: 50px;"><img class="alignnone size-full wp-image-222" src="/wp-content/uploads/2017/08/имплантация.png" alt="" /></td>
					<td><span style="color: #2d70cc;">Консультация врача</span></td>
					<td style="width: 50px; text-align: right; color: #2d70cc;"><i class="fa fa-arrow-circle-down"></i></td>
				</tr>
			</table>
			<? $menu = wp_get_nav_menu_items('Консультация врача'); ?>
			<ul class="oglavl">
				<? foreach ($menu as $item) { $title = explode('|', $item->title)[0]; $price = explode('|', $item->title)[1]; ?>
				<li><span class="text"><? echo $title; ?></span><span class="page"><? echo $price; ?> <i class="fa fa-rub"></i></span></li>
				<? } ?>
			</ul>
			<ul class="features">
				<li><span class="cards-icons">Visa, Mastercard</span></li>
				<li><a href="/patients/%D0%B8%D0%BD%D0%BE%D0%B3%D0%BE%D1%80%D0%BE%D0%B4%D0%BD%D0%B8%D0%BC-%D0%BF%D0%B0%D1%86%D0%B8%D0%B5%D0%BD%D1%82%D0%B0%D0%BC/">Иногородним пациентам</a></li>
				<li><a href="/patients/оплата-услуг/">Оплата услуг</a></li>
			</ul>
			<div style="height: 0px; width: 100%; border-top: 1px solid #2d70cc; padding-left: 10px; margin-bottom:30px; margin-top: 30px;"></div>
		</div>

		<div class="col col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
			<table class="price-head" style="width: 100%;">
				<tr>
					<td style="width: 50px;"><img class="alignnone size-full wp-image-136" src="/wp-content/uploads/2017/08/дмс-1.png" alt="" width="42" height="50" /></td>
					<td><span style="color: #2d70cc;">Диагностика</span></td>
					<td style="width: 50px; text-align: right; color: #2d70cc;"><i class="fa fa-arrow-circle-down"></i></td>
				</tr>
			</table>
			<? $menu = wp_get_nav_menu_items('Диагностика'); ?>
			<ul class="oglavl">
				<? foreach ($menu as $item) { $title = explode('|', $item->title)[0]; $price = explode('|', $item->title)[1]; ?>
				<li><span class="text"><? echo $title; ?></span><span class="page"><? echo $price; ?> <i class="fa fa-rub"></i></span></li>
				<? } ?>
			</ul>
			<ul class="features">
				<li><span class="cards-icons">Visa, Mastercard</span></li>
				<li><a href="/patients/%D0%B8%D0%BD%D0%BE%D0%B3%D0%BE%D1%80%D0%BE%D0%B4%D0%BD%D0%B8%D0%BC-%D0%BF%D0%B0%D1%86%D0%B8%D0%B5%D0%BD%D1%82%D0%B0%D0%BC/">Иногородним пациентам</a></li>
				<li><a href="/patients/оплата-услуг/">Оплата услуг</a></li>
			</ul>
			<div style="height: 0px; width: 100%; border-top: 1px solid #2d70cc; padding-left: 10px; margin-bottom:30px; margin-top: 30px;"></div>
		</div>
		
		<div class="col col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
			<table class="price-head" style="width: 100%;">
				<tr>
					<td style="width: 50px;"><img class="alignnone size-full wp-image-136" src="/wp-content/uploads/2017/08/кариес.png" alt="" width="42" height="50" /></td>
					<td><span style="color: #2d70cc;">Терапия</span></td>
					<td style="width: 50px; text-align: right; color: #2d70cc;"><i class="fa fa-arrow-circle-down"></i></td>
				</tr>
			</table>
			<? $menu = wp_get_nav_menu_items('Терапия'); ?>
			<ul class="oglavl">
				<? foreach ($menu as $item) { $title = explode('|', $item->title)[0]; $price = explode('|', $item->title)[1]; ?>
				<li><span class="text"><? echo $title; ?></span><span class="page"><? echo $price; ?> <i class="fa fa-rub"></i></span></li>
				<? } ?>
			</ul>
			<ul class="features">
				<li><span class="cards-icons">Visa, Mastercard</span></li>
				<li><a href="/patients/%D0%B8%D0%BD%D0%BE%D0%B3%D0%BE%D1%80%D0%BE%D0%B4%D0%BD%D0%B8%D0%BC-%D0%BF%D0%B0%D1%86%D0%B8%D0%B5%D0%BD%D1%82%D0%B0%D0%BC/">Иногородним пациентам</a></li>
				<li><a href="/patients/оплата-услуг/">Оплата услуг</a></li>
			</ul>
			<div style="height: 0px; width: 100%; border-top: 1px solid #2d70cc; padding-left: 10px; margin-bottom:30px; margin-top: 30px;"></div>
		</div>
		
		<div class="col col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
			<table class="price-head" style="width: 100%;">
				<tr>
					<td style="width: 50px;"><img class="alignnone size-full wp-image-136" src="/wp-content/uploads/2017/08/обезболивание.png" alt="" width="42" height="50" /></td>
					<td><span style="color: #2d70cc;">Анестезия</span></td>
					<td style="width: 50px; text-align: right; color: #2d70cc;"><i class="fa fa-arrow-circle-down"></i></td>
				</tr>
			</table>
			<? $menu = wp_get_nav_menu_items('Анестезия'); ?>
			<ul class="oglavl">
				<? foreach ($menu as $item) { $title = explode('|', $item->title)[0]; $price = explode('|', $item->title)[1]; ?>
				<li><span class="text"><? echo $title; ?></span><span class="page"><? echo $price; ?> <i class="fa fa-rub"></i></span></li>
				<? } ?>
			</ul>
			<ul class="features">
				<li><span class="cards-icons">Visa, Mastercard</span></li>
				<li><a href="/patients/%D0%B8%D0%BD%D0%BE%D0%B3%D0%BE%D1%80%D0%BE%D0%B4%D0%BD%D0%B8%D0%BC-%D0%BF%D0%B0%D1%86%D0%B8%D0%B5%D0%BD%D1%82%D0%B0%D0%BC/">Иногородним пациентам</a></li>
				<li><a href="/patients/оплата-услуг/">Оплата услуг</a></li>
			</ul>
			<div style="height: 0px; width: 100%; border-top: 1px solid #2d70cc; padding-left: 10px; margin-bottom:30px; margin-top: 30px;"></div>
		</div>
		
				
		<div class="col col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
			<table class="price-head" style="width: 100%;">
				<tr>
					<td style="width: 50px;"><img class="alignnone size-full wp-image-136" src="/wp-content/uploads/2017/08/инвизиолайн.png" alt="" width="42" height="50" /></td>
					<td><span style="color: #2d70cc;">Ортодонтия</span></td>
					<td style="width: 50px; text-align: right; color: #2d70cc;"><i class="fa fa-arrow-circle-down"></i></td>
				</tr>
			</table>
			<? $menu = wp_get_nav_menu_items('Ортодонтия'); ?>
			<ul class="oglavl">
				<? foreach ($menu as $item) { $title = explode('|', $item->title)[0]; $price = explode('|', $item->title)[1]; ?>
				<li><span class="text"><? echo $title; ?></span><span class="page"><? echo $price; ?> <i class="fa fa-rub"></i></span></li>
				<? } ?>
			</ul>
			<ul class="features">
				<li><span class="cards-icons">Visa, Mastercard</span></li>
				<li><a href="/patients/%D0%B8%D0%BD%D0%BE%D0%B3%D0%BE%D1%80%D0%BE%D0%B4%D0%BD%D0%B8%D0%BC-%D0%BF%D0%B0%D1%86%D0%B8%D0%B5%D0%BD%D1%82%D0%B0%D0%BC/">Иногородним пациентам</a></li>
				<li><a href="/patients/оплата-услуг/">Оплата услуг</a></li>
			</ul>
			<div style="height: 0px; width: 100%; border-top: 1px solid #2d70cc; padding-left: 10px; margin-bottom:30px; margin-top: 30px;"></div>
		</div>
		
		<div class="col col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
			<table class="price-head" style="width: 100%;">
				<tr>
					<td style="width: 50px;"><img class="alignnone size-full wp-image-136" src="/wp-content/uploads/2017/08/протезирование.png" alt="" width="42" height="50" /></td>
					<td><span style="color: #2d70cc;">Ортопедия</span></td>
					<td style="width: 50px; text-align: right; color: #2d70cc;"><i class="fa fa-arrow-circle-down"></i></td>
				</tr>
			</table>
			<? $menu = wp_get_nav_menu_items('Ортопедия'); ?>
			<ul class="oglavl">
				<? foreach ($menu as $item) { $title = explode('|', $item->title)[0]; $price = explode('|', $item->title)[1]; ?>
				<li><span class="text"><? echo $title; ?></span><span class="page"><? echo $price; ?> <i class="fa fa-rub"></i></span></li>
				<? } ?>
			</ul>
			<ul class="features">
				<li><span class="cards-icons">Visa, Mastercard</span></li>
				<li><a href="/patients/%D0%B8%D0%BD%D0%BE%D0%B3%D0%BE%D1%80%D0%BE%D0%B4%D0%BD%D0%B8%D0%BC-%D0%BF%D0%B0%D1%86%D0%B8%D0%B5%D0%BD%D1%82%D0%B0%D0%BC/">Иногородним пациентам</a></li>
				<li><a href="/patients/оплата-услуг/">Оплата услуг</a></li>
			</ul>
			<div style="height: 0px; width: 100%; border-top: 1px solid #2d70cc; padding-left: 10px; margin-bottom:30px; margin-top: 30px;"></div>
		</div>
		<div class="col col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
			<table class="price-head" style="width: 100%;">
				<tr>
					<td style="width: 50px;"><img class="alignnone size-full wp-image-136" src="/wp-content/uploads/2017/08/гигиена.png" alt="" width="55" height="50" /></td>
					<td><span style="color: #2d70cc;">Пародонтология</span></td>
					<td style="width: 50px; text-align: right; color: #2d70cc;"><i class="fa fa-arrow-circle-down"></i></td>
				</tr>
			</table>
			<? $menu = wp_get_nav_menu_items('Пародонтология'); ?>
			<ul class="oglavl">
				<? foreach ($menu as $item) { $title = explode('|', $item->title)[0]; $price = explode('|', $item->title)[1]; ?>
				<li><span class="text"><? echo $title; ?></span><span class="page"><? echo $price; ?> <i class="fa fa-rub"></i></span></li>
				<? } ?>
			</ul>
			<ul class="features">
				<li><span class="cards-icons">Visa, Mastercard</span></li>
				<li><a href="/patients/%D0%B8%D0%BD%D0%BE%D0%B3%D0%BE%D1%80%D0%BE%D0%B4%D0%BD%D0%B8%D0%BC-%D0%BF%D0%B0%D1%86%D0%B8%D0%B5%D0%BD%D1%82%D0%B0%D0%BC/">Иногородним пациентам</a></li>
				<li><a href="/patients/оплата-услуг/">Оплата услуг</a></li>
			</ul>
			<div style="height: 0px; width: 100%; border-top: 1px solid #2d70cc; padding-left: 10px; margin-bottom:30px; margin-top: 30px;"></div>
		</div>
		<div class="col col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
			<table class="price-head" style="width: 100%;">
				<tr>
					<td style="width: 50px;"><img class="alignnone size-full wp-image-136" src="/wp-content/uploads/2017/08/имплантация.png" alt="" width="35" height="50" /></td>
					<td><span style="color: #2d70cc;">Имплантология</span></td>
					<td style="width: 50px; text-align: right; color: #2d70cc;"><i class="fa fa-arrow-circle-down"></i></td>
				</tr>
			</table>
			<? $menu = wp_get_nav_menu_items('Имплантология'); ?>
			<ul class="oglavl">
				<? foreach ($menu as $item) { $title = explode('|', $item->title)[0]; $price = explode('|', $item->title)[1]; ?>
				<li><span class="text"><? echo $title; ?></span><span class="page"><? echo $price; ?> <i class="fa fa-rub"></i></span></li>
				<? } ?>
			</ul>
			<ul class="features">
				<li><span class="cards-icons">Visa, Mastercard</span></li>
				<li><a href="/patients/%D0%B8%D0%BD%D0%BE%D0%B3%D0%BE%D1%80%D0%BE%D0%B4%D0%BD%D0%B8%D0%BC-%D0%BF%D0%B0%D1%86%D0%B8%D0%B5%D0%BD%D1%82%D0%B0%D0%BC/">Иногородним пациентам</a></li>
				<li><a href="/patients/оплата-услуг/">Оплата услуг</a></li>
			</ul>
			<div style="height: 0px; width: 100%; border-top: 1px solid #2d70cc; padding-left: 10px; margin-bottom:30px; margin-top: 30px;"></div>
		</div>
		
		<div class="col col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
			<table class="price-head" style="width: 100%;">
				<tr>
					<td style="width: 50px;"><img class="alignnone size-full wp-image-136" src="/wp-content/uploads/2017/08/лечение-под-микроскопом.png" alt="" width="60" height="50" /></td>
					<td><span style="color: #2d70cc;">Лечение под микроскопом</span></td>
					<td style="width: 50px; text-align: right; color: #2d70cc;"><i class="fa fa-arrow-circle-down"></i></td>
				</tr>
			</table>
			<? $menu = wp_get_nav_menu_items('Лечение под микроскопом'); ?>
			<ul class="oglavl">
				<? foreach ($menu as $item) { $title = explode('|', $item->title)[0]; $price = explode('|', $item->title)[1]; ?>
				<li><span class="text"><? echo $title; ?></span><span class="page"><? echo $price; ?> <i class="fa fa-rub"></i></span></li>
				<? } ?>
			</ul>
			<ul class="features">
				<li><span class="cards-icons">Visa, Mastercard</span></li>
				<li><a href="/patients/%D0%B8%D0%BD%D0%BE%D0%B3%D0%BE%D1%80%D0%BE%D0%B4%D0%BD%D0%B8%D0%BC-%D0%BF%D0%B0%D1%86%D0%B8%D0%B5%D0%BD%D1%82%D0%B0%D0%BC/">Иногородним пациентам</a></li>
				<li><a href="/patients/оплата-услуг/">Оплата услуг</a></li>
			</ul>
			<div style="height: 0px; width: 100%; border-top: 1px solid #2d70cc; padding-left: 10px; margin-bottom:30px; margin-top: 30px;"></div>
		</div>
		<div class="col col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
			<table class="price-head" style="width: 100%;">
				<tr>
					<td style="width: 50px;"><img class="alignnone size-full wp-image-136" src="/wp-content/uploads/2017/08/отбеливание.png" alt="" width="60" height="50" /></td>
					<td><span style="color: #2d70cc;">Гигиена полости рта</span></td>
					<td style="width: 50px; text-align: right; color: #2d70cc;"><i class="fa fa-arrow-circle-down"></i></td>
				</tr>
			</table>
			<? $menu = wp_get_nav_menu_items('Гигиена полости рта'); ?>
			<ul class="oglavl">
				<? foreach ($menu as $item) { $title = explode('|', $item->title)[0]; $price = explode('|', $item->title)[1]; ?>
				<li><span class="text"><? echo $title; ?></span><span class="page"><? echo $price; ?> <i class="fa fa-rub"></i></span></li>
				<? } ?>
			</ul>
			<ul class="features">
				<li><span class="cards-icons">Visa, Mastercard</span></li>
				<li><a href="/patients/%D0%B8%D0%BD%D0%BE%D0%B3%D0%BE%D1%80%D0%BE%D0%B4%D0%BD%D0%B8%D0%BC-%D0%BF%D0%B0%D1%86%D0%B8%D0%B5%D0%BD%D1%82%D0%B0%D0%BC/">Иногородним пациентам</a></li>
				<li><a href="/patients/оплата-услуг/">Оплата услуг</a></li>
			</ul>
			<div style="height: 0px; width: 100%; border-top: 1px solid #2d70cc; padding-left: 10px; margin-bottom:30px; margin-top: 30px;"></div>
		</div>
		
		<div class="col col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
			<table class="price-head" style="width: 100%;">
				<tr>
					<td style="width: 50px;"><img class="alignnone size-full wp-image-136" src="/wp-content/uploads/2017/08/виниры.png" alt="" width="42" height="50" /></td>
					<td><span style="color: #2d70cc;">Виниры</span></td>
					<td style="width: 50px; text-align: right; color: #2d70cc;"><i class="fa fa-arrow-circle-down"></i></td>
				</tr>
			</table>
			<? $menu = wp_get_nav_menu_items('Виниры'); ?>
			<ul class="oglavl">
				<? foreach ($menu as $item) { $title = explode('|', $item->title)[0]; $price = explode('|', $item->title)[1]; ?>
				<li><span class="text"><? echo $title; ?></span><span class="page"><? echo $price; ?> <i class="fa fa-rub"></i></span></li>
				<? } ?>
			</ul>
			<ul class="features">
				<li><span class="cards-icons">Visa, Mastercard</span></li>
				<li><a href="/patients/%D0%B8%D0%BD%D0%BE%D0%B3%D0%BE%D1%80%D0%BE%D0%B4%D0%BD%D0%B8%D0%BC-%D0%BF%D0%B0%D1%86%D0%B8%D0%B5%D0%BD%D1%82%D0%B0%D0%BC/">Иногородним пациентам</a></li>
				<li><a href="/patients/оплата-услуг/">Оплата услуг</a></li>
			</ul>
			<div style="height: 0px; width: 100%; border-top: 1px solid #2d70cc; padding-left: 10px; margin-bottom:30px; margin-top: 30px;"></div>
		</div>
		
		<div class="col col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
			<table class="price-head" style="width: 100%;">
				<tr>
					<td style="width: 50px;"><img class="alignnone size-full wp-image-136" src="/wp-content/uploads/2017/08/отзывы.png" alt="" width="42" height="50" /></td>
					<td><span style="color: #2d70cc;">Компьютерная томография</span></td>
					<td style="width: 50px; text-align: right; color: #2d70cc;"><i class="fa fa-arrow-circle-down"></i></td>
				</tr>
			</table>
			<? $menu = wp_get_nav_menu_items('Компьютерная томография'); ?>
			<ul class="oglavl">
				<? foreach ($menu as $item) { $title = explode('|', $item->title)[0]; $price = explode('|', $item->title)[1]; ?>
				<li><span class="text"><? echo $title; ?></span><span class="page"><? echo $price; ?> <i class="fa fa-rub"></i></span></li>
				<? } ?>
			</ul>
			<ul class="features">
				<li><span class="cards-icons">Visa, Mastercard</span></li>
				<li><a href="/patients/%D0%B8%D0%BD%D0%BE%D0%B3%D0%BE%D1%80%D0%BE%D0%B4%D0%BD%D0%B8%D0%BC-%D0%BF%D0%B0%D1%86%D0%B8%D0%B5%D0%BD%D1%82%D0%B0%D0%BC/">Иногородним пациентам</a></li>
				<li><a href="/patients/оплата-услуг/">Оплата услуг</a></li>
			</ul>
			<div style="height: 0px; width: 100%; border-top: 1px solid #2d70cc; padding-left: 10px; margin-bottom:30px; margin-top: 30px;"></div>
		</div>
		</div>
	</div>
</section>
<? get_footer(); ?>